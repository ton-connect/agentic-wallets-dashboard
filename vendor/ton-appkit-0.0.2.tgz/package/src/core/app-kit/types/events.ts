/**
 * Copyright (c) TonTech.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */

import type { Network } from '../../../types/network';
import type { Emitter } from '../../emitter';
import type { CONNECTOR_EVENTS, WALLETS_EVENTS, PLUGIN_EVENTS, NETWORKS_EVENTS } from '../constants/events';
import type { WalletInterface } from '../../../types/wallet';

export interface WalletConnectedPayload {
    wallets: WalletInterface[];
    connectorId: string;
}

export interface WalletDisconnectedPayload {
    connectorId: string;
}

export interface PluginRegisteredPayload {
    pluginId: string;
    pluginType: string;
}

export interface DefaultNetworkChangedPayload {
    network: Network | undefined;
}

export interface AppKitEvents {
    // Connector events
    [CONNECTOR_EVENTS.CONNECTED]: WalletConnectedPayload;
    [CONNECTOR_EVENTS.DISCONNECTED]: WalletDisconnectedPayload;

    // Wallets events
    [WALLETS_EVENTS.UPDATED]: { wallets: WalletInterface[] };
    [WALLETS_EVENTS.SELECTION_CHANGED]: { walletId: string | null };

    // Networks events
    [NETWORKS_EVENTS.UPDATED]: Record<string, never>;
    [NETWORKS_EVENTS.DEFAULT_CHANGED]: DefaultNetworkChangedPayload;

    // Plugin events
    [PLUGIN_EVENTS.REGISTERED]: PluginRegisteredPayload;
}

export type AppKitEmitter = Emitter<AppKitEvents>;
